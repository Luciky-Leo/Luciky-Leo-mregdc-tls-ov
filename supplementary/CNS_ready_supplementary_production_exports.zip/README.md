﻿# Supplementary Figure Production Exports

This folder contains production-grade exports for Supplementary Figures S1-S7 after CNS-style supplementary figure optimization.

Each figure includes:

- PDF: fixed-width 180 mm page for review and vector-preserving upload/editing.
- SVG: editable vector text/objects where applicable.
- TIFF: 600 dpi high-resolution raster export for journal production requests.

S3 is a layout-redrawn spatial-map page derived from the prior S3 spatial-map PDF source layer; it is not a new spatial analysis.
